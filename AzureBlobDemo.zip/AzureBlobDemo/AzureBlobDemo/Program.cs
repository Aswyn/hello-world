﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;   // added
using System.Threading.Tasks;
using System.Configuration;   // added
using Microsoft.Azure;        // added for blob
using Microsoft.WindowsAzure.Storage;  // added for blob
using Microsoft.WindowsAzure.Storage.Blob;  // added for blob
using Microsoft.WindowsAzure.Storage.Auth;   // added for blob
using System.Data.SqlClient;    // added for Azure SQL Server Database
using System.Data;       // added for Azure SQL Server Database

// Import NuGet Package -  WindowsAzure.Storage  and  WindowsAzure.ConfigurationManager

namespace AzureBlobDemo
{
    class Program
    {

      //  private readonly string CONN_STRING_SETTING = "AzureStorageConnectionString";
       // private readonly CloudBlobClient _client;
       // private readonly CloudBlobContainer _container;


        static void Main(string[] args)
        {
            // calling method
            //   CreateBlobContainer();
            DeleteBlob();
            Console.ReadKey();
        }


        // Method to create Azure Storage container , working code snippet
        public static void CreateBlobContainer()
        {
            //Reference to the ConnectionString in the App.Config file
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnection"));
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("images");
            container.CreateIfNotExists(BlobContainerPublicAccessType.Blob);

            // This will set metadata for container 
            container.Metadata.Clear();
            container.Metadata.Add("Owner", "Aswyn Reddy");
            container.Metadata["LastUpdated"] = DateTime.Now.ToString();
            container.SetMetadata();

    /*-------------------------------------------------------------------------------------------------------------------*/

        /*
            var blob = container.GetBlockBlobReference(blobName);
            blob.UploadText("1234");

            // Add metadata to blob
            blob.Metadata["Item1"] = "Value1";
            blob.Metadata["Item2"] = "Value2";
            blob.SetMetadata();


            // fetch the blob metadata
            var blobReloaded = container.GetBlockBlobReference(blobName);
            blobReloaded.FetchAttributes();
            Console.WriteLine(blobReloaded.Metadata["Item1"]);
            Console.WriteLine(blobReloaded.Metadata["Item2"]);
        */


        }


        /*

        public void SaveMetaData(string fileName, string container, string key, string value)
        {
            var blob = GetBlobReference(fileName, container);
            blob.FetchAttributes();
            blob.Metadata.Add(key, value);
            blob.SetMetadata();
        }

    */



        /*        
           // Method to delete blob
           public async Task Delete(string blobName)
           {
               var blob = _container.GetBlobReference(blobName);
               await blob.DeleteIfExistsAsync();
           }

       */


        /*      
          // Method to delete Blob , working code snippet
          public static void DeleteBlob()
          {
              //Reference to the ConnectionString in the App.Config file
              CloudStorageAccount storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnection"));
              CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
              CloudBlobContainer container = blobClient.GetContainerReference("adftest");
              CloudBlockBlob blockBlob = container.GetBlockBlobReference("orders.json");
              // blockBlob.DeleteAsync();
              bool x = blockBlob.DeleteIfExists();
            //  bool x = await blockBlob.DeleteIfExistsAsync();    // returns Task<bool> true (successfully deleted) , false (container did not exist)

              if (x)
              {
                  Console.WriteLine("Blob deleted successfully");
              }else
              {
                  Console.WriteLine("Order Blob not found");
              } 


          }

      */



        public static void DeleteBlob()
        {

            string conn = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;

            string query = "SELECT ordernumber FROM dbo.ordernumbers";

            SqlConnection connection = new SqlConnection(conn);

            SqlDataAdapter dadapter = new SqlDataAdapter(query, connection);

            DataSet ds = new DataSet();

            connection.Open();

            dadapter.Fill(ds, "ordernumbers");

            connection.Close();


            //Reference to the ConnectionString in the App.Config file
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnection"));
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("adftest");
            CloudBlockBlob blockBlob = container.GetBlockBlobReference("orders.json");
            bool x = blockBlob.DeleteIfExists();

            if (x)
            {
                Console.WriteLine("Blob deleted successfully");
            }
            else
            {
                Console.WriteLine("Order Blob not found");
            }


        }






    }


}
