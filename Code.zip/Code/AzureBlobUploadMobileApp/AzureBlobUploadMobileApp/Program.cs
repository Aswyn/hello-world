﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.Auth;
using System.Data.SqlClient;
using System.Data;
using System.IO;

namespace AzureBlobUploadMobileApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Calling BLOB upload method
            UploadBlob();
            Console.ReadKey();

        }


        //Method to upload BLOB
        public static void UploadBlob()
        {
            string localFolder = ConfigurationManager.AppSettings["sourceFolder"];
            /*
            string sqlConn = ConfigurationManager.ConnectionStrings["AzureSqlDBConnection"].ConnectionString;
            string query = "SELECT ordernumber FROM tstmobileappdb.dbo.ordernumbers";
            SqlConnection connection = new SqlConnection(sqlConn);
            SqlDataAdapter dadapter = new SqlDataAdapter(query, connection);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            connection.Open();
            dadapter.Fill(ds, "ordernumbers");
            dt = ds.Tables["ordernumbers"];
            connection.Close();
            */

            //Reference to the ConnectionString in the App.Config file
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnection"));
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("adftest");
            //  CloudBlockBlob blockBlob = container.GetBlockBlobReference(dr["ordernumber"].ToString() + ".json");

            string[] fileEntries = Directory.GetFiles(localFolder);
            
            foreach(string filePath in fileEntries)
            {

                string key = Path.GetFileName(filePath);

                CloudBlockBlob blob = container.GetBlockBlobReference(key);

                using (var fs = System.IO.File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    blob.UploadFromStream(fs);

                }

            }

        }


    }
}
